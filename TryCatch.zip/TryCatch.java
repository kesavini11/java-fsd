
public class TryCatch {

	public static void main(String[] args) {
		int a = 150;
		int b = 0;
		int n;
		try
		{
			n=a/b;
		}
		catch(Exception e)
		{
			System.out.println(a/(b+3));
		}
	}

}
