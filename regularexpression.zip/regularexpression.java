import java.util.regex.*;
public class regularexpression {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("Welcome", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher("Welcome to your Home");
		boolean matchFound = matcher.find();
		if(matchFound) {
			System.out.println("It is found");
			}
		else { 
			System.out.println("It is not found");
		    }

	}

}
