package ClassObjectAndPillars;

class Student{  
	 int rollno;  
	 String name;  
	 void insertRecord(int r, String n){  
	  rollno=r;  
	  name=n;  
	 }  
	 void displayInformation(){System.out.println(rollno+" "+name);}  
	}  

public class TestStudent {
	
	public static void main(String args[]){  
		  Student s1=new Student();  
		  Student s2=new Student();  
		  s1.insertRecord(13456,"akash");  
		  s2.insertRecord(12345,"mona");  
		  s1.displayInformation();  
		  s2.displayInformation();  
	}
}
