package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bean.product;

public class ProductDao {

		public int storeProduct(product product) {
			try {
				Configuration con = new Configuration();
				con.configure("hibernate.cfg.xml");
				SessionFactory sf = con.buildSessionFactory();
				Session session = sf.openSession();
				
				Transaction tran = session.getTransaction();
				tran.begin();
						session.save(product);
				tran.commit();
				return 1;
			} catch (Exception e) {
				System.out.println(e);
				return 0;
			}
		}
		
		
		public int deleteProduct(int pid) {
				Configuration con = new Configuration();
				con.configure("hibernate.cfg.xml");
				SessionFactory sf = con.buildSessionFactory();
				Session session = sf.openSession();
				Transaction tran = session.getTransaction();
				product pp	= session.get(product.class, pid);
				if(pp==null) {
					return 0;
				}else {
					tran.begin();	
					
					session.delete(pp);
					
					tran.commit();
					return 1;
				}
			
		}
		
		
		public int updateProduct(product product) {
			Configuration con = new Configuration();
			con.configure("hibernate.cfg.xml");
			SessionFactory sf = con.buildSessionFactory();
			Session session = sf.openSession();
			Transaction tran = session.getTransaction();
			product pp	= session.get(product.class, product.getPid());
			if(pp==null) {
				return 0;
			}else {
				tran.begin();	
				
				pp.setPrice(product.getPrice());    
				//pp.setPrice(pp.getPrice()+100);
					session.update(pp); // update Product set price = newprice where pid = 100    
				tran.commit();
				return 1;
			}
		
	}
		
		
	public product findProduct(int pid) {
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory sf = con.buildSessionFactory();
		Session session = sf.openSession();
		product pp	= session.get(product.class, pid);
		return pp;
	}	
	
}


