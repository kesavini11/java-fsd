package com.products;


import java.util.ArrayList;

public class ProductDetails{
	private int id;
	private String name;
	private String category;
	private float price;
	
	public ProductDetails(int id, String name, String category, float price){
		this.id=id;
		this.name=name;
		this.category=category;
		this.price=price;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getCategory() {
		return category;
	}

	public float getPrice() {
		return price;
	}
	
	public ArrayList<ProductDetails> getProductDetails()
	{
		ArrayList<ProductDetails> productList = new ArrayList<ProductDetails>();
		 
		productList.add(new ProductDetails(id, name, category, price));  
		 
		 for (ProductDetails s : productList) 
			{
				System.out.print("ID, Name, Category, and Price of the product are : ");
				System.out.println(s.id + " " + s.name + " " + s.category + " " + s.price);
			}
		return productList;
	}
}





