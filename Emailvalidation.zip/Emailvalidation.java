package program2;

import java.util.regex.*;

import java.util.*;
  
public class Emailvalidation
{
    public static boolean isValid(String email)
    {
        String emailRegex = "^(.+)@(.+)$";
                              
        Pattern pat = Pattern.compile(emailRegex);
        if (email == null)
            return false;
        return pat.matcher(email).matches();
    }
  
    public static void main(String[] args)
    {
        String email = "ajay23@gmail.com";
        boolean result = isValid(email);
        if(result == true)
                System.out.println("Provided email address "+ email+" is Valid \n");
            
            else
            	
            	System.out.println("Provided email address "+ email+" is Invalid \n");
    }
}
