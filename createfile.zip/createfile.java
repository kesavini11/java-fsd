import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;

public class createfile {
	
	public static void main(String[] args) {
		
		try {
			File obj = new File("C:\\Users\\USER\\Desktop\\sample.txt");
			if(obj.exists())
				
			{
				FileWriter Writer = new FileWriter("C:\\Users\\USER\\Desktop\\sample.txt");
	
				Writer.write("Welcome Everyone\n");
				Writer.write("Happy Morning\n");
				Writer.write("Have a grear day!");
			    System.out.println("File write successfully");
				
				BufferedWriter appendtxt = new BufferedWriter (Writer);
				
				System.out.println("please enter to be append");
				Scanner sc = new Scanner(System.in);
				String data = sc.nextLine();
				appendtxt.append(data);
				appendtxt.close();      
				Writer.close();
				
				System.out.println("File append successfully");
				Scanner reader  = new Scanner(obj); 
				while(reader.hasNext())
				{
					String txt =  reader.nextLine();    
					System.out.println("content in the files:"+" "+txt);
					System.out.println("File read successfully");           
					}
				reader.close();
			}
			else 
				if(obj.createNewFile()) {
					System.out.println("File created:"+""+obj.getName());
					System.out.println("File created successfully");
				}
				else
				{
					System.out.println("File not create");
					
				}
		
		}
		catch(Exception e)
		{     
			System.out.println("Error occurred");
			e.printStackTrace();
		}
	}
}

