package ArrayAndList;

public class Arrayrotate {

	public static void main(String[] args) {
		
		 int [] a = new int [] {1,2,4,6,8};   
		 int n = 3;    
		 System.out.println("Original array: ");    
		 for (int i = 0; i < a.length; i++)
		 {     
			 System.out.print(a[i] + " ");     
			 }      
		 for(int i = 0; i < n; i++){    
			 int j, last;    
			 last = a[a.length-1];    
			 for(j = a.length-1; j > 0; j--){   	                   
				 a[j] = a[j-1];   
				 }    	             
			 a[0] = last;    
			 }    	        
		 System.out.println();    	            
		 System.out.println("Array after rotation: ");    
		 for(int i = 0; i< a.length; i++){    
			 System.out.print(a[i] + " ");    
			 }    
		 }    
	}    

