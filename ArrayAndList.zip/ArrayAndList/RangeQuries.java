package ArrayAndList;

import java.util.*;

public class RangeQuries {

	public static void main(String[] args) {
		int L, R;
		System.out.println("Enter the numbers:");
		Scanner sc = new Scanner(System.in);
		L = sc.nextInt();
		R = sc.nextInt();
		int i, sum = 0;
		for(i = L; i <= R; i++)
		{
			sum = sum + i;
		}
		System.out.print(sum);
	}

}
