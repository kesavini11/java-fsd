package ArrayAndList;

public class OrderStatistics {
	
	public void sortArr(int a[])  
	{  
	int size = a.length;  
	for(int i = 0; i < size; i++)  
	{  
		int temp = i;  
		for(int j = i + 1; j < size; j++)  	
		{
			if(a[temp] > a[j])  
			{  
				temp = j;  
				} 	 
			}    
		if(temp != i)  
		{  
			int t = a[i];  
			a[i] = a[temp];  
			a[temp] = t;   
			}  
		}  
	}  
	public int findKthSmallest(int a[], int k)  
	{  
		sortArr(a);  
		return a[k - 1];  
		}  
	public static void main(String argvs[])  
	{ 
		OrderStatistics obj = new OrderStatistics();
		int a[] = {8,5,6,7,2,9,4};  
	  
	int size = a.length;  
	int k = 4;  
	  
	System.out.println("For the array: ");  
	for(int i = 0; i < size; i++)  
	{  
	System.out.print(a[i] + " ");  
	}  
	  
	int element = obj.findKthSmallest(a, k);  
	  
	System.out.println();  
	System.out.println("The " + k + "th smallest element of the array is: " + element);  
	}
}

