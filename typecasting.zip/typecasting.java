
public class typecasting {

	public static void main(String[] args) {
		System.out.println("Implicit Type Casting");
		int num1 = 10;
        System.out.println("The integer value: " +num1);
        double data = num1;
        System.out.println("The double value: " +data);
        System.out.println("Explicit Type Casting");
        double num2 = 10.99;
        System.out.println("The double value: " +num2);
        int data1 = (int)num2;
        System.out.println("The integer value: " +data1);
	}
}

		