package ArrayAndList;


import java.util.Stack;

public class InsertAndRemoveStack {

	public static void main(String[] args) {
		
		Stack<String> StudentNameStack = new Stack<String>();
		StudentNameStack.add("Abi");
		StudentNameStack.add("Arjun");
		StudentNameStack.add("Vignesh");
		StudentNameStack.add("Joy");
		System.out.println("Stack is : " + StudentNameStack);
		System.out.println("Remove : " + StudentNameStack.peek());
		StudentNameStack.remove("Arjun");
		System.out.println("After removing : " + StudentNameStack);

	}

}
