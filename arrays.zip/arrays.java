
public class arrays {

	public static void main(String[] args) {
		int a[] = {10,30,40,70};
		
	    int i;
	    
		int n = a.length;
		
		for(i=0;i<n;i++) {
			
			System.out.println(a[i]);
		}
		
    System.out.println("The length of array is: "+n);
	}
}
