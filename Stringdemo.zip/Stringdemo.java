import java.util.Scanner;
public class Stringdemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.next();
		String b = sc.next();
				
		System.out.println(a.length());
		System.out.println(a.toUpperCase());
		System.out.println(b.isEmpty());
		System.out.println(b.compareTo(a));
		
		
		StringBuffer s = new StringBuffer(a);
		System.out.println(s.append(" Have a good day"));
		System.out.println(s.delete(0, 2));
		System.out.println("StringBulider");
		
		StringBuilder f = new StringBuilder(b);
		System.out.println(f.insert(0, "welcome"));
		System.out.println(f.reverse());
		System.out.println();
	}
}
