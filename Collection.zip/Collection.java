 
import java.util.*; 
  
public class Collection { 
  
    public static void main(String[] args) 
    { 
    	ArrayList a = new ArrayList();
    	a.add("mona");
    	a.add("jack");
    	System.out.println("ArrayList: ");
    	System.out.println(a);
    	HashSet h = new HashSet();
    	h.add(100);
    	h.add(400);
    	System.out.println("HashSet: ");
    	System.out.println(h);
    	System.out.println("HashSet:");
    	Iterator i = h.iterator();
    	while(i.hasNext()) {
    		System.out.println(i.next());
    	}
    	System.out.println("ArrayList: ");
    	Iterator A = a.iterator();
    	while(A.hasNext()) {
    		System.out.println(A.next());
    	}
    }
}
    	