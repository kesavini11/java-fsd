import java.util.*;
public class Maps {
	public static void main(String[] args) {
        
        Map<String, Integer> n = new HashMap<>();

        
        n.put("four" ,1);
        n.put("ten" ,2);
        System.out.println("Map: " + n);

        
        System.out.println("Keys: " + n.keySet());

        
        System.out.println("Values: " + n.values());

        
        System.out.println("Entries: " + n.entrySet());

        
        int value = n.remove("ten");
        System.out.println("Removed Value: " + value);
    }
}


