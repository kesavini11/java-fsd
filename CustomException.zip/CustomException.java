
class validAgeException  extends Exception  
{  
    public validAgeException (String str)  
    {  
        super(str);  
    }  
}  
      
public class CustomException 
	{  
		static void validate (int age) throws validAgeException{    
	       if(age > 18){  
	  
	          
	        throw new validAgeException("Age is valid ");    
	    }  
	       else {   
	        System.out.println("Age is not valid ");   
	        }   
	     }   
	public static void main(String[] args) {

	    {  
	        try  
	        {  
	            
	            validate(23);  
	        }  
	        catch (validAgeException ex)  
	        {  
	            System.out.println("Caught the exception");  
	     
	            System.out.println("Exception occured: " + ex);  
	        }  
	  
	        System.out.println("Welcome!!");    
	    }  
	} 

}
