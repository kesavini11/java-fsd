
public class ThrowKeyword {
	static void checkAge(int age) {
	    if (age < 18) {
	      throw new ArithmeticException("you are not Eligible for voting");
	    }
	    else {
	      System.out.println("you are Eligible for voting");
	    }
	  }

	  public static void main(String[] args) {
	    checkAge(18); 
	    System.out.println("Have a great day!");
	  }
	}