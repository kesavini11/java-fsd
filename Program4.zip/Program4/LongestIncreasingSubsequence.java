package Program4;
import java.util.Scanner;

public class LongestIncreasingSubsequence {
	public int[] lis(int[] Z)	
	{        	      
		int A = Z.length - 1;	
		int[] B = new int[A + 1];  	 
		int[] C = new int[A + 1]; 
		int L = 0;
		for (int i = 1; i < A + 1; i++)
		{
			int j = 0;
			for (int pos = L ; pos >= 1; pos--)
			{
				if (Z[B[pos]] <Z[i])
				{
					j = pos;
					break;
					}
				}            
			C[i] = B[j];
			if (j == L || Z[i] < Z[B[j + 1]])
			{
				B[j + 1] = i;
				L = Math.max(L,j + 1);
				}
			}
		int[] data = new int[L];
		int pos = B[L];
		for (int i = L - 1; i >= 0; i--)
		{
			data[i] = Z[pos];
			pos = C[pos];
			}
		return data;             
		} 
	public static void main(String[] args) 
	{    
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter no of elements");
		int n = scan.nextInt();
	    int[] arr = new int[n + 1];
		System.out.println("\nEnter "+ n +" elements");
		for (int i = 1; i <= n; i++)
			arr[i] = scan.nextInt();
		LongestIncreasingSubsequence obj = new LongestIncreasingSubsequence(); 
		int[] data = obj.lis(arr);       
		System.out.print("\nLongest Increasing Subsequence : ");
		for (int i = 0; i < data.length; i++)
			System.out.print(data[i] +" ");
	        System.out.println();
	}
}

