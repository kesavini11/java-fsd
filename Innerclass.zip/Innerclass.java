

public class Innerclass { 
	private String msg="Welcome to class";  
	
	class Inner1{  
		void hello(){
			System.out.println(msg+", This is my inner class1");
			} 
		}  
	class Inner2{
		void display(){
			System.out.println("This is my inner class2");
		}
	}
	public  static void main(String[] args) {
	
	Innerclass o = new Innerclass();
	Innerclass.Inner1 i = o.new Inner1(); 
	i.hello();
	Innerclass.Inner2 in = o.new Inner2(); 
	in.display();
	}
}

