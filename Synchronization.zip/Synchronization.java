class first
{
	public void display(String msg)
	{
		System.out.println("welcome"+msg);
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("my"+msg);
	}
}
class second extends Thread
{
	String msg;
	first fo;
	second(first fp,String str)
	{
		fo = fp;
		msg = str;
		start();
	}
	public void run()
	{
		fo.display(msg);
	}
}
public class Synchronization {

	public static void main(String[] args) {
		first fnew = new first();
		second ss = new second(fnew, " friends");
		second ss1 = new second(fnew, " students");
		second ss2 = new second(fnew, " family");
		}
	}
