package ArrayAndList;

import java.util.*;


public class InsertAndRemovequeue {

	public static void main(String[] args) {
		
		Queue<String> animationQueue = new LinkedList<>();
		animationQueue.add("Nemo");
		animationQueue.add("Frozen");
		animationQueue.add("Mona");
		animationQueue.add("Cinderella");
	
		System.out.println("Queue is : " + animationQueue);
		System.out.println("Remove : " + animationQueue.peek());
		animationQueue.remove();
		System.out.println("After removing : " + animationQueue);
	}

}
