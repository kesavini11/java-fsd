package demo;
class operation {
	public void area(int r) {
	double area = 3.142*r*r;
	System.out.println("Area of circle "+area);
	}

public void area(int b, int h) {
	double area = 0.5*b*h;
	System.out.println("Area of triangle "+area);
	}
}
public class compiletimepolymorphism {
	public static void main(String[] args) {
		operation op = new operation();
		op.area(4);
		op.area(10,12);
	}
}

