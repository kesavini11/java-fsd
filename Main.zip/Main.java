package Assessmentproject1;

import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args)  {
	        File folder = new File("C:\\Users\\USER\\Desktop\\myfile");
	        folder.mkdirs();
	        Scanner sc = new Scanner(System.in);
	        while(true){
	        	System.out.println(" ********************  \n");
	        	System.out.println("Welcome to LockedMe.com \n");
	        	System.out.println(" ********************  \n");
	            System.out.println("1. To display all files inside \n");
	            System.out.println("2. To display menu for file operation  \n");
	            System.out.println("3. Exit the Program \n");
	            System.out.println("Please choose your option \n");
	            int option = sc.nextInt();
	            switch(option)
	            {
	            case 1:
	            	File arr[] = folder.listFiles();
	            	Arrays.sort(arr);
	            	for(int i=0;i<arr.length;i++)
	            		System.out.println(arr[i]);
	            	break;
	            	case 2:
	            		Boolean temp = true;
	            		while(temp) {
	            			System.out.println("Option 1 : I wish to add a file");
	                        System.out.println("Option 2 : I wish to delete a file ");
	                        System.out.println("Option 3 : I wish to search a file");
	                        System.out.println("Option 4 : Go to the previous menu");
	                        System.out.println("Option 5 : Exit the program");
	                       
	                        int option2 = sc.nextInt();
	                        switch (option2) {
	                        case 1:               
	                        	System.out.println("Enter the name of the file");
	                        	String name = sc.next();
	                        	if(new File(folder,name).exists()){
	                        		System.out.println("File is already exist");
	                        		}else {
	                        			File f1 = new File(folder, name);	                        			
	                        			f1.mkdir();
	                        			if (new File(folder, name).exists()) {
	                        				System.out.println("File successfully added");
	                        				}
	                        			}
	                        	break;
	                        	case 2:
	                        		System.out.println("Enter the name of the file");
	                        		String name1 = sc.next();
	                        		boolean f2 = new File(folder, name1).exists();
	                        		System.out.println(f2);
	                        		if (f2 == true) {
	                        			File f3 = new File(folder, name1);
	                                    f3.delete();
	                                    System.out.println("File successfully deleted");
	                                } else {
	                                    System.out.println("File does not exist");
	                                }
	                                break;
	                                case 3:
	                                	System.out.println("Please enter the Filename:");
	                                	String Search = sc.next();
	                                	File a1[]=folder.listFiles();
	                                	for(int i = 0; i < a1.length; i++) {
	                                		if(a1[i].getName().startsWith(Search)) {
	                                			System.out.println(a1[i]);
	                                			System.out.println("File is found");
	                                			break;
	                                			}
	                                		else
	                                		{	
	                                			System.out.println("File not found");
	                                			}
	                                		}
	                                	break;
	                                	case 4:
	                                		temp = false;	                                	
	                                		break;
	                                		case 5:
	                                			System.out.println("Program Exited Successfully!");
	                                			System.exit(0);
	                                			default:	        
	                                				System.out.println("choose valid option!");
	                                				}
	                        }	                                		                                				
	            		break;
	            		case 3:
	            			System.out.println("Program Exited Successfully");
	            			System.exit(0);	            		
	            			default:
	            				System.out.println(" choose valid option!");
	            				break;
	            }
	        }
	}
}
	                          


	        
