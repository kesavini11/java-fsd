
public class ExceptionHandler {

	public static void main(String[] args) {
		try {
			int dividebyzero = 20/0;
			System.out.println("In this block");
		}
		catch(ArithmeticException e) {
			System.out.println("ArithmeticException --> "+e.getMessage());
		}
	}
}
		


